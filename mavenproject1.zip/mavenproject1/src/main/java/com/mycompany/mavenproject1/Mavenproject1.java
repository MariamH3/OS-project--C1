/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author MANDO
 */
import javafx.application.Application;
import javafx.stage.Stage;
public class Mavenproject1 extends Application {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }

    @Override
    public void start(Stage stage) throws Exception {
        
    }
}
